#ifndef __BASE_LAYER_H__
#define __BASE_LAYER_H__
#include "cocos2d.h"
#include "ui/CocosGUI.h"
using namespace cocos2d;
using namespace ui;
class BaseLayer : public Layer {
protected:
	Button *m_lockButton;
	virtual bool init();
public:
	CREATE_FUNC(BaseLayer);

	void setEnableLockTouch(bool value);
	void setLockTouchArea(Rect area);
	void resetLockTouchArea();
};
#endif 