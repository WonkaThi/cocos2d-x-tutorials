#include "BaseLayer.h"
bool BaseLayer::init() {
	if (!Layer::init()) {
		return false;
	}
	Size ws = Director::getInstance()->getWinSize();

	m_lockButton = Button::create();
	addChild(m_lockButton);
	m_lockButton->setAnchorPoint(Point::ZERO);
	m_lockButton->setScale9Enabled(true);
	m_lockButton->setContentSize(ws);

	return true;
}

void BaseLayer::setEnableLockTouch(bool value) {
	m_lockButton->setVisible(value);
}

void BaseLayer::setLockTouchArea(Rect area) {
	m_lockButton->setPosition(area.origin);
	m_lockButton->setContentSize(area.size);
}

void BaseLayer::resetLockTouchArea() {
	m_lockButton->setPosition(Point::ZERO);
	m_lockButton->setContentSize(Director::getInstance()->getWinSize());
}