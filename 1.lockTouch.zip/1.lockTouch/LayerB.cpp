#include "LayerB.h"

bool LayerB::init(){
	if (!BaseLayer::init()) {
		return false;
	}

	Size ws = Director::getInstance()->getWinSize();
	Button *button = Button::create("");
	button->setTitleText("LayerB");
	button->setTitleFontSize(30);
	addChild(button);
	button->setPosition(Point(3* ws.width / 4.0f, ws.height / 2.0f));
	button->addTouchEventListener([](Ref *sender, Widget::TouchEventType type) {
		if (type == Widget::TouchEventType::ENDED) {
			((Button *)sender)->runAction(Sequence::create(ScaleTo::create(2, 2), ScaleTo::create(2, 1), nullptr));
		}
	});

	m_lockButton->addTouchEventListener([button](Ref *sender, Widget::TouchEventType type) {
		switch (type)
		{
		case cocos2d::ui::Widget::TouchEventType::BEGAN: {
			break;
		}
		case cocos2d::ui::Widget::TouchEventType::MOVED:{
		}
		case cocos2d::ui::Widget::TouchEventType::ENDED:{
			if (button->isVisible()) {
			    button->setVisible(false);
			}
			else {
			    button->setVisible(true);
			}
			break;
		}
		case cocos2d::ui::Widget::TouchEventType::CANCELED:
			break;
		default:
			break;
		}
	});
	return true;
}

void LayerB::callBackButton(Ref *sender, Widget::TouchEventType type) {

}