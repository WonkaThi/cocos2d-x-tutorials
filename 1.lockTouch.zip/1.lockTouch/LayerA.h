#ifndef __LAYER_A__
#define __LAYER_A__
#include "BaseLayer.h"

class LayerA : public BaseLayer {
protected:
	virtual bool init();
public:
	CREATE_FUNC(LayerA);
};
#endif