#ifndef __LAYER_B__
#define __LAYER_B__
#include "BaseLayer.h"

class LayerB : public BaseLayer {
	void callBackButton(Ref *sender, Widget::TouchEventType type);
protected:
	virtual bool init();
public:
	CREATE_FUNC(LayerB);
};
#endif