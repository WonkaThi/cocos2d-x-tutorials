#include "LayerA.h"

bool LayerA::init(){
	if (!BaseLayer::init()) {
		return false;
	}

	Size ws = Director::getInstance()->getWinSize();
	Button *button = Button::create("");
	button->setTitleText("LayerA");
	button->setTitleFontSize(30);
	addChild(button);
	button->setPosition(Point(ws.width / 4.0f, ws.height / 2.0f));
	button->addTouchEventListener([](Ref *sender, Widget::TouchEventType type) {
		if (type == Widget::TouchEventType::ENDED) {
			((Button *)sender)->runAction(Sequence::create(ScaleTo::create(2, 2), ScaleTo::create(2, 1), nullptr));
		}
	});
	

	return true;
}